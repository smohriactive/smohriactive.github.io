﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollowBehaviour2 : MonoBehaviour {
	
	public Transform target;
	private float forwardDistance;
	private float followSpeed = 5f;
	
	// Use this for initialization
	void Start () {
		forwardDistance = Mathf.Abs (transform.position.z - target.position.z);
	}
	
	// Update is called once per frame
	void Update () {
		Debug.Log("Rotation: Up -> Down");

		// Delta position
		Vector3 cameraFollowDistance = Vector3.zero;
		cameraFollowDistance.x = target.position.x / 2;
		cameraFollowDistance.y = transform.position.y;
		cameraFollowDistance.z = target.position.z - forwardDistance;

		transform.position = Vector3.Lerp(transform.position, cameraFollowDistance, Time.deltaTime * followSpeed);
	}
}
