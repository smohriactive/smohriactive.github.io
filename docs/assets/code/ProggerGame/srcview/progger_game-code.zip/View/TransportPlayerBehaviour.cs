﻿using UnityEngine;

public class TransportPlayerBehaviour : MonoBehaviour {

	private GameModel gameModel = GameModel.GetInstance;

	void OnTriggerEnter(Collider other) {
		Debug.Log("NPC Behaviour: Transport");

		if (other.gameObject.tag == "Player") {
			other.transform.parent = transform;
			gameModel.isTransporting = true;
		}
	}

	void OnTriggerStay(Collider other) {
		
	}

	void OnTriggerExit(Collider other) {
		if (other.gameObject.tag == "Player") {
			other.transform.parent = null;

			gameModel.isTransporting = false;
		}
	}
}
