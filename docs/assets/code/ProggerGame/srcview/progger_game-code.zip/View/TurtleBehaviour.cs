﻿using UnityEngine;

public class TurtleBehaviour : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Debug.Log("Start Turtle");

		transform.rotation = Quaternion.Euler(0, -90, 0);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
