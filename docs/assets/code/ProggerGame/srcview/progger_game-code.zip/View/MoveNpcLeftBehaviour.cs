﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveNpcLeftBehaviour : MonoBehaviour {

	private GameModel gameModel = GameModel.GetInstance;

	private int startPos = GameModel.SPAWN_SIZE;
	private int endPos = -GameModel.SPAWN_SIZE;
	private int rangeFactor = 7;
	private MoveNpcLeftBehaviour otherNpc;
	private CharacterController controller;

	public float npcSpeed = GameModel.SPEED_NPC;

	// Use this for initialization
	void Start () {
		controller = GetComponent<CharacterController>();
		npcSpeed = Random.Range(GameModel.SPEED_NPC - rangeFactor, GameModel.SPEED_NPC + rangeFactor);
	}

	void OnTriggerEnter(Collider other) {
		if (this != other) {
			otherNpc = other.gameObject.GetComponent<MoveNpcLeftBehaviour>() as MoveNpcLeftBehaviour;
			if (otherNpc != null) {
				if (other.transform.position.x < transform.position.x) {
					otherNpc.npcSpeed += rangeFactor;
				} else {
					otherNpc.npcSpeed -= rangeFactor;
				}
			}

			if (other.transform.position.x < transform.position.x) {
				npcSpeed -= rangeFactor;
			} else {
				npcSpeed += rangeFactor;
			}
		}
	}

	void OnTriggerExit(Collider other) {
		if (this != other) {
			if (otherNpc != null) {
				if (other.transform.position.x < transform.position.x) {
					otherNpc.npcSpeed = Random.Range(GameModel.SPEED_NPC - rangeFactor, GameModel.SPEED_NPC + rangeFactor);
					npcSpeed = Random.Range(otherNpc.npcSpeed - rangeFactor, otherNpc.npcSpeed);
				} else {
					npcSpeed = Random.Range(GameModel.SPEED_NPC - rangeFactor, GameModel.SPEED_NPC + rangeFactor);
					otherNpc.npcSpeed = Random.Range(npcSpeed - rangeFactor, npcSpeed);
				}

				otherNpc = null;
			}
		}
	}
	
	// Update is called once per frame
	void Update () {
		if (transform.position.x > endPos) {
			controller.SimpleMove(Vector3.left * npcSpeed);
		} else if (gameModel.npcList.Remove (gameObject)) {
			Destroy (gameObject);
		}
	}
}
