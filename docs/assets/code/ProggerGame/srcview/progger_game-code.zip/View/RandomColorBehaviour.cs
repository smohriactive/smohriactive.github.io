﻿using UnityEngine;

public class RandomColorBehaviour : MonoBehaviour {

	public Color farbe;

	void Start () {
		GameUtils.GenerateRandomColor(this);
	}
}
