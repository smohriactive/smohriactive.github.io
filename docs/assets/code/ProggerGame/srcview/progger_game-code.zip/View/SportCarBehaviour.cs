﻿using UnityEngine;

public class SportCarBehaviour : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Debug.Log("Start SportCar");

		transform.rotation = Quaternion.Euler(0, -90, 0);
	}
	
	void Update () {
	}
}
