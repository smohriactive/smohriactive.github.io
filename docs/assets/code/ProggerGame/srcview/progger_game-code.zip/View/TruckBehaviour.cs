﻿using UnityEngine;

public class TruckBehaviour : MonoBehaviour {

	private const string EMPTY = "Empty";
	private const string DACH = "Dach";
	private const string STAURAUM = "Stauraum";

	// Use this for initialization
	void Start () {
		Debug.Log("Start Truck");

		Renderer[] components = GetComponentsInChildren<Renderer>();
		string[] choiceNames = new string[]{EMPTY, DACH, STAURAUM};
		int choice = Random.Range (0, 3);

		foreach (Renderer childRenderer in components) {

			switch (choiceNames[choice]) {
				case DACH:
					if (childRenderer.name == STAURAUM) {
						childRenderer.enabled = false;
					}
					break;
				case STAURAUM:
					if (childRenderer.name == DACH) {
						childRenderer.enabled = false;
					}
					break;
				default:
					if (childRenderer.name == DACH) {
						childRenderer.enabled = false;
					}
					if (childRenderer.name == STAURAUM) {
						childRenderer.enabled = false;
					}
					break;
			}
		}

		transform.rotation = Quaternion.Euler(0, -90, 0);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
