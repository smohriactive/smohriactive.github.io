﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameUtils {

	public static void GenerateRandomColor(Component component) {
		// Get all Renderers
		Renderer[] components = component.GetComponentsInChildren<Renderer>();
		foreach (Renderer gameobject in components) {
			// Choose random color for each material
			foreach (Material material in gameobject.materials) {
				material.color = new Color(Random.value, Random.value, Random.value);
			}
		}
	}
}
