﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class DamagePlayerBehaviour : MonoBehaviour {
	
	private GameModel gameModel = GameModel.GetInstance;

	void Start() {
		Debug.Log("New Game: Damage");
	}
	
	void OnTriggerEnter(Collider other) {
		if (other.gameObject.tag == "Player") {
			if (gameModel.health > 0) {
				gameModel.health -= GameModel.GAME_DAMAGE;
			}
			if (gameModel.health <= 0) {
				if (gameModel.pointsValue > gameModel.hiScoreValue) {
					gameModel.hiScoreValue = gameModel.pointsValue;
					PlayerPrefs.SetFloat("hiScore", gameModel.hiScoreValue);
				}
				gameModel.isGameOver = true;
				gameModel.isMenuPanelVisible = true;
			}
		}
	}
}	
