﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseGameBehaviour : MonoBehaviour {
	
	private bool isGameRunning = false;

	// Use this for initialization
	void Start () {
	}

	// Update is called once per frame
	void Update () {
		bool escapeDown = Input.GetKeyDown(KeyCode.Escape);

		if (escapeDown) {
			if (isGameRunning) {
				Time.timeScale = 1;
				isGameRunning = false;
			} else {
				Time.timeScale = 0;
				isGameRunning = true;
			}
		}
	}
}
