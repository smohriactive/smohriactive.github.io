﻿using UnityEngine;
using UnityEngine.UI;

public class NewGameTask : MonoBehaviour
{
	private GameModel gameModel = GameModel.GetInstance;

	public Button yourButton;

	void Start()
	{
		Button btn = yourButton.GetComponent<Button>();
		btn.onClick.AddListener(TaskOnClick);
	}

	public void TaskOnClick()
	{
		Debug.Log("New Game");

		gameModel.highestForwardPosition = GameModel.PLAYER_START_POS_Z;
		gameModel.resetPosition = true;
		gameModel.playerPosition = GameModel.PLAYER_START_POS;
		gameModel.playerRotation = GameModel.ROTATION_UP;

		gameModel.health = GameModel.GAME_HEALTH;
		gameModel.isGameOver = false;
		gameModel.isMenuPanelVisible = false;
	}
}
