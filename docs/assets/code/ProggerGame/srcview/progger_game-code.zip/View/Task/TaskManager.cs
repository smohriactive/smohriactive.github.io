﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TaskManager : MonoBehaviour {

	private GameModel gameModel = GameModel.GetInstance;

	void Awake () {
		if (PlayerPrefs.HasKey ("hiScore")) {
			gameModel.hiScoreValue = PlayerPrefs.GetFloat("hiScore");
		}
	}

	// Update is called once per frame
	void Update () {
		bool escapeDown = Input.GetKeyDown(KeyCode.Escape);

		if (escapeDown) {
			if (gameModel.isGamePaused) {
				ContinueGame ();
			} else {
				PauseGame ();
			}
		}
	}

	public void ExitGame ()
	{
		Application.Quit();
	}

	public void NewGame ()
	{
		Debug.Log("New Game");

		gameModel.highestForwardPosition = GameModel.PLAYER_START_POS_Z;
		gameModel.resetPosition = true;
		gameModel.pointsValue = 0;
		gameModel.playerPosition = GameModel.PLAYER_START_POS;
		gameModel.playerRotation = GameModel.ROTATION_UP;

		gameModel.health = GameModel.GAME_HEALTH;
		gameModel.isGameOver = false;

		ContinueGame ();
	}

	public void ContinueGame ()
	{
		Time.timeScale = 1;
		gameModel.isGamePaused = false;
		gameModel.isMenuPanelVisible = false;
		gameModel.isOptionsPanelVisible = false;
	}

	public void PauseGame ()
	{
		gameModel.isGamePaused = true;
		gameModel.isMenuPanelVisible = true;
		Time.timeScale = 0;
	}

	public void ShowMenu ()
	{
		gameModel.isMenuPanelVisible = true;
		gameModel.isOptionsPanelVisible = false;
	}

	public void ShowOptions ()
	{
		gameModel.isMenuPanelVisible = false;
		gameModel.isOptionsPanelVisible = true;
	}
}
