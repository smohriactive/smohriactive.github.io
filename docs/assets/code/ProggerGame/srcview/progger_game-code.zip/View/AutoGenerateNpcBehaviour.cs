﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AutoGenerateNpcBehaviour : MonoBehaviour {

	public GameObject[] leftObjects;
	public GameObject[] rightObjects;

	private string[] leftPrefabNames = new string[]{"Prefab/TestplattformPrefab", "Prefab/TestplattformPrefab", "Prefab/TestplattformPrefab"};
	private string[] rightPrefabNames = new string[]{"Prefab/TruckPrefab", "Prefab/TrabbiPrefab", "Prefab/PickupTruckPrefab", "Prefab/SportCarPrefab"};

	private GameModel gameModel = GameModel.GetInstance;

	void Start() {
		InvokeRepeating ("TaskOnClick", 1f, 1f);
	}

	private void TaskOnClick()
	{
		float zPos;
		Vector3 pos;
		GameObject clone;
		GameObject loadedGameObject;

		int streetIndex;
		int numOfStreets = 5;
		float streetIslandSize = GameModel.TILE_SIZE / 2;
		float streetSpace = ((GameModel.NUM_OF_TILES * GameModel.TILE_SIZE) / 2) - streetIslandSize - GameModel.TILE_SIZE;
		float streetSize = streetSpace / numOfStreets;

		switch (Random.Range (1, 2)) {
			case 0:
				streetIndex = Random.Range (0, numOfStreets);
				zPos = (streetIndex * streetSize) + GameModel.TILE_SIZE;
				pos = new Vector3 (-GameModel.SPAWN_SIZE, 0, zPos);
				loadedGameObject = Resources.Load(leftPrefabNames [Random.Range (0, 2)]) as GameObject;
				clone = Instantiate(loadedGameObject, pos, Quaternion.Euler (Vector3.right));
				gameModel.npcList.Add (clone);
				break;
			case 1:
				streetIndex = Random.Range (0, numOfStreets);
				zPos = ((streetIndex * streetSize) + GameModel.TILE_SIZE) * -1;
				pos = new Vector3 (GameModel.SPAWN_SIZE, 0, zPos);
				loadedGameObject = Resources.Load(rightPrefabNames [Random.Range (0, 4)]) as GameObject;
				clone = Instantiate(loadedGameObject, pos, Quaternion.Euler (Vector3.left));
				gameModel.npcList.Add (clone);
				break;
		}
	}
}
