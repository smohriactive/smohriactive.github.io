﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

[RequireComponent(typeof(TextMeshProUGUI))]
public class GameOverTextUpdater : MonoBehaviour
{
	private GameModel gameModel = GameModel.GetInstance;
	private bool isGameOver = false;
	private TextMeshProUGUI text;

	// Use this for initialization
	void Start ()
	{
		text = GetComponent<TextMeshProUGUI>();
		text.enabled = isGameOver;
	}
	
	// Update is called once per frame
	void Update ()
	{
		if (gameModel.isGameOver != isGameOver)
		{
			isGameOver = gameModel.isGameOver;
			text.enabled = isGameOver;
		}
	}
}
