﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ContinueGameButtonUpdater : MonoBehaviour
{
	private GameModel gameModel = GameModel.GetInstance;
	private bool isGamePaused = false;
	private Button button;

	// Use this for initialization
	void Start ()
	{
		button = GetComponentInChildren<Button>();
		button.gameObject.SetActive(isGamePaused);
	}

	// Update is called once per frame
	void Update ()
	{
		Debug.Log ("I am in");

		if (isGamePaused != gameModel.isGamePaused)
		{
			isGamePaused = gameModel.isGamePaused;
			button.gameObject.SetActive(isGamePaused);
		}
	}
}
