﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KingSeatUpdater : MonoBehaviour {

	public string seatName;

	private GameModel gameModel = GameModel.GetInstance;

	private Renderer littleFrog;
	private Renderer kingsCrown;

	// Use this for initialization
	void Start () {
		// Get all Renderers
		Renderer[] kingSeatitems = GetComponentsInChildren<Renderer> ();

		foreach (Renderer item in kingSeatitems) {
			if (item.name == "FrogMesh") {
				littleFrog = item;
			}
			if (item.name == "KingsCrown") {
				kingsCrown = item;
			}
		}

		littleFrog.gameObject.SetActive (false);
		kingsCrown.gameObject.SetActive (false);
	}

	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "Player")
		{
			gameModel.resetPosition = true;
			gameModel.playerPosition = GameModel.PLAYER_START_POS;

			littleFrog.material.color = other.gameObject.GetComponentInChildren<Renderer> ().material.color;

			GameUtils.GenerateRandomColor(other);

			gameModel.pointsValue += 200;

			littleFrog.gameObject.SetActive (true);
			kingsCrown.gameObject.SetActive (true);
		}
	}
}
