﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class LittleFrogUpdater : MonoBehaviour {

	private GameModel gameModel = GameModel.GetInstance;
	private CharacterController controller;

	public float speed = 6.0F;
	public float jumpSpeed = 8.0F;
	public float gravity = 20.0F;
	private Vector3 moveDirection = Vector3.zero;

	// Use this for initialization
	void Start () {
		controller = GetComponent<CharacterController>();
	}

	// Update is called once per frame
	void Update () {

		// Move Player

		if (gameModel.resetPosition) {
			transform.position = gameModel.playerPosition;
			gameModel.resetPosition = false;
		} else {
			// TODO
//			transform.position = Vector3.MoveTowards(transform.position, gameModel.playerPosition, Time.deltaTime * GameModel.SPEED_PLAYER);

			Vector3 direction = gameModel.playerPosition - transform.position;
			direction.y -= gravity * Time.deltaTime * GameModel.SPEED_PLAYER;
			direction.Normalize(); // Make sure to have a pure "unit" direction 
			Debug.Log ("Player Direction: " + direction);

			controller.Move(direction * Time.deltaTime * 10000f);
		}

		if (transform.rotation != gameModel.playerRotation) {
			transform.rotation = gameModel.playerRotation;
		}
	}
}
