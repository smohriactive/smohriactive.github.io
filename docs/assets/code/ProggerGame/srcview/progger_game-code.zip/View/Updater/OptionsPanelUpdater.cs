﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OptionsPanelUpdater : MonoBehaviour {

	private GameModel gameModel = GameModel.GetInstance;
	private bool isOptionsPanelVisible = false;

	private CanvasGroup canvasGroup;
	private Animator[] animators;

	// Use this for initialization
	void Start () {
		canvasGroup = GetComponent<CanvasGroup> ();
		canvasGroup.alpha = 0;
		canvasGroup.blocksRaycasts = false; 
		canvasGroup.interactable = false;

		animators = GetComponentsInChildren<Animator> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (gameModel.isOptionsPanelVisible != isOptionsPanelVisible) {
			isOptionsPanelVisible = gameModel.isOptionsPanelVisible;

			if (isOptionsPanelVisible) {
				canvasGroup.alpha = 1;
				canvasGroup.blocksRaycasts = true;
				canvasGroup.interactable = true;
			} else {
				canvasGroup.alpha = 0;
				canvasGroup.blocksRaycasts = false; 
				canvasGroup.interactable = false;
			}

			if (isOptionsPanelVisible) {
				foreach (Animator animator in animators) {
					animator.Play ("Normal");
				}
			}
		}
	}
}
