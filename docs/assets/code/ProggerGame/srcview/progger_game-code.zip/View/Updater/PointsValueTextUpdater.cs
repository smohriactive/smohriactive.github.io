﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

[RequireComponent(typeof(TextMeshProUGUI))]
public class PointsValueTextUpdater : MonoBehaviour {

	private GameModel gameModel = GameModel.GetInstance;
	private float oneUpValue = 0f;
	private TextMeshProUGUI text;

	// Use this for initialization
	void Start () {
		text = GetComponent<TextMeshProUGUI>();
		text.text = oneUpValue.ToString();
	}

	// Update is called once per frame
	void Update () {
		if (gameModel.pointsValue != oneUpValue) {
			oneUpValue = gameModel.pointsValue;
			text.text = oneUpValue.ToString();
		}
	}
}
