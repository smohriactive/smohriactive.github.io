﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PointCountUpdater : MonoBehaviour {

	private GameModel gameModel = GameModel.GetInstance;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (gameModel.playerPosition.z > gameModel.highestForwardPosition) {
			gameModel.pointsValue += GameModel.POINTS_STEP;
			gameModel.highestForwardPosition = gameModel.playerPosition.z;
		}
	}
}
