﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Slider))]
public class HealthSliderUpdater : MonoBehaviour {

	private GameModel gameModel = GameModel.GetInstance;
	private float health = 1f;
	private Slider slider;

	// Use this for initialization
	void Start () {
		slider = GetComponent<Slider>();
	}
	
	// Update is called once per frame
	void Update () {
		if (gameModel.health != health) {
			health = gameModel.health;
			slider.value = health;
		}
	}
}
