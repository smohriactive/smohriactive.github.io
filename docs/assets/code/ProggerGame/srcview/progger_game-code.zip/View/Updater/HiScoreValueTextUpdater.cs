﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

[RequireComponent(typeof(TextMeshProUGUI))]
public class HiScoreValueTextUpdater : MonoBehaviour {

	private GameModel gameModel = GameModel.GetInstance;
	private float hiScoreValue = 0f;
	private TextMeshProUGUI text;

	// Use this for initialization
	void Start () {
		text = GetComponent<TextMeshProUGUI>();
		text.text = hiScoreValue.ToString();
	}

	// Update is called once per frame
	void Update () {
		if (gameModel.hiScoreValue != hiScoreValue) {
			hiScoreValue = gameModel.hiScoreValue;
			text.text = hiScoreValue.ToString();
		}
	}
}
