﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrunkBehaviour : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Debug.Log("Start Trunk");

//		transform.rotation = Quaternion.Euler(-90, -90, 0);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
