﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaneManager : MonoBehaviour {
	private int leftMaxPos = -GameModel.SPAWN_SIZE;
	private int rightMaxPos = GameModel.SPAWN_SIZE;
	private List<Component> laneObjects;

	public int laneNumber = 1;
	public DirectionType direction = DirectionType.Left;

	public enum DirectionType 
	{
		Left,
		Right
	}

	public float npcSpeed = GameModel.SPEED_NPC;

	// Use this for initialization
	void Start () {
		int numOfLanes = 5;
		float laneIslandSize = GameModel.TILE_SIZE / 2;
		float laneSpace = ((GameModel.NUM_OF_TILES * GameModel.TILE_SIZE) / 2) - laneIslandSize - GameModel.TILE_SIZE;
		float laneSize = laneSpace / numOfLanes;
		float zPos = (laneNumber * laneSize); // + GameModel.TILE_SIZE;

		transform.position = new Vector3 (transform.position.x, transform.position.y, zPos);

		laneObjects = new List<Component> ();
		laneObjects.AddRange (GetComponentsInChildren<Renderer> ());

		foreach (Component laneObject in laneObjects) {
			laneObject.transform.localPosition = new Vector3 (laneObject.transform.localPosition.x, laneObject.transform.localPosition.y, 0);
		}
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		foreach (Component laneObject in laneObjects) {
			if (direction == DirectionType.Left) {
				if (laneObject.transform.localPosition.x < leftMaxPos) {
					laneObject.transform.localPosition = new Vector3 (rightMaxPos, laneObject.transform.localPosition.y, laneObject.transform.localPosition.z);
				} else {
					laneObject.transform.Translate (Vector3.left * Time.deltaTime * npcSpeed, Space.World);
				}
			} else if (direction == DirectionType.Right) {
				if (laneObject.transform.localPosition.x > rightMaxPos) {
					laneObject.transform.localPosition = new Vector3 (leftMaxPos, laneObject.transform.localPosition.y, laneObject.transform.localPosition.z);
				} else {
					laneObject.transform.Translate (Vector3.right * Time.deltaTime * npcSpeed, Space.World);
				}
			}
		}
	}
}
