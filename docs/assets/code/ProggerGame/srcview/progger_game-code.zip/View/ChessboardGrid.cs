﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChessboardGrid : MonoBehaviour {

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		DrawChessboard ();
	}

	/**
	 * 
	 */
	private void DrawChessboard() {
		Vector3 widthLine = Vector3.right * GameModel.TILE_SIZE * GameModel.NUM_OF_TILES;
		Vector3 heightLine = Vector3.forward * GameModel.TILE_SIZE * GameModel.NUM_OF_TILES;
		float halfBoard = (GameModel.NUM_OF_TILES * GameModel.TILE_SIZE) / 2;

		for (int i = 0; i <= GameModel.NUM_OF_TILES; i++) {
			
			Vector3 start = Vector3.forward * i * GameModel.TILE_SIZE;
			start.x = start.x - halfBoard;
			start.z = start.z - halfBoard;
			Debug.DrawLine (start, start + widthLine, Color.red);

			for (int j = 0; j <= GameModel.NUM_OF_TILES; j++) {
				start = Vector3.right * j * GameModel.TILE_SIZE;
				start.x = start.x - halfBoard;
				start.z = start.z - halfBoard;
				Debug.DrawLine (start, start + heightLine, Color.red);
			}
		}
	}
}
