﻿using UnityEngine;

public class CrocodileBehaviour : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Debug.Log("Start Crocodile");

		transform.rotation = Quaternion.Euler(0, 90, 0);
	}
	
	// Update is called once per frame
	void Update () {
		// Debug.Log("Croc Crocodile");
	}

	void OnDestroy () {
		
	}
}
