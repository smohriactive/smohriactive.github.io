﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBehaviour : MonoBehaviour {

	private float speed = 0.2F;
	private float gravity = 0.2F;

	private GameModel gameModel = GameModel.GetInstance;
	private CharacterController controller;

	private Vector3 lastPosition = Vector3.zero;
	private Vector3 nextPosition = Vector3.zero;
	private Vector3 step = Vector3.zero;
	private Vector3 move = Vector3.zero;
	private bool isDirectionDirty = false;
	private bool isGravityDirty = false;

	private KeyCode lastKey = KeyCode.UpArrow;

	// Use this for initialization
	void Start () {
		Debug.Log("Start TileMove");

		controller = GetComponent<CharacterController>();
	}

	// Update is called once per frame
	void Update () {

		if (gameModel.resetPosition) {
			gameModel.resetPosition = false;
			transform.position = gameModel.playerPosition;
		}

		bool upArrowDown = Input.GetKeyDown(KeyCode.UpArrow);
		bool downArrowDown = Input.GetKeyDown(KeyCode.DownArrow);
		bool leftArrowDown = Input.GetKeyDown(KeyCode.LeftArrow);
		bool rightArrowDown = Input.GetKeyDown(KeyCode.RightArrow);

		if (!isDirectionDirty & !isGravityDirty) {
			if (upArrowDown) {
				// New Move Position
				move = step = transform.TransformDirection(Vector3.forward * GameModel.TILE_SIZE);
				lastPosition = transform.position;
				nextPosition = transform.position + step;

				// New Rotate Position
				updateRotation (lastKey, KeyCode.UpArrow);
				lastKey = KeyCode.UpArrow;

				isDirectionDirty = true;
			} else if (downArrowDown) {
				// New Move Position
				move = step = transform.TransformDirection(Vector3.back * GameModel.TILE_SIZE);
				lastPosition = transform.position;
				nextPosition = transform.position + step;

				// New Rotate Position
				updateRotation (lastKey, KeyCode.DownArrow);
				lastKey = KeyCode.DownArrow;

				isDirectionDirty = true;
			} else if (leftArrowDown) {
				// New Move Position
				move = step = transform.TransformDirection(Vector3.left * GameModel.TILE_SIZE);
				lastPosition = transform.position;
				nextPosition = transform.position + step;

				// New Rotate Position
				updateRotation (lastKey, KeyCode.LeftArrow);
				lastKey = KeyCode.LeftArrow;

				isDirectionDirty = true;
			} else if (rightArrowDown) {
				// New Move Position
				move = step = transform.TransformDirection(Vector3.right * GameModel.TILE_SIZE);
				lastPosition = transform.position;
				nextPosition = transform.position + step;

				// New Rotate Position
				updateRotation (lastKey, KeyCode.RightArrow);
				lastKey = KeyCode.RightArrow;

				isDirectionDirty = true;
			}
		}

		if (isDirectionDirty) {
			float delta = Time.deltaTime;

			Debug.Log("Schritt: " + step + ", Pos-Ist: " + transform.position + ", Pos-Soll:" + nextPosition);

			CollisionFlags flags = controller.Move (move);

			// Check Step Complete
			move = nextPosition - transform.position;

			if (haveSamePosition (transform.position, nextPosition)) {
				Debug.Log("Pos gefunden !!!");

				isDirectionDirty = false;
				lastPosition = nextPosition;
				nextPosition = Vector3.zero;
				step = Vector3.zero;
				move = Vector3.zero;
				isGravityDirty = true;
			}
		}

		if (isGravityDirty) {
//			isGravityDirty = false;
			if (controller.isGrounded) {
				step = Vector3.zero;
				isGravityDirty = false;
			} else {
				step.y -= gravity * Time.deltaTime;
				controller.Move (step);
			}
		}

		if (controller.transform.rotation != gameModel.playerRotation) {
			controller.transform.rotation = gameModel.playerRotation;
		}
	}

	private bool haveSamePosition(Vector3 vec1, Vector3 vec2) {
		return Mathf.Round(vec1.x) == Mathf.Round(vec2.x) &&
			Mathf.Round(vec1.z) == Mathf.Round(vec2.z);
	}

	private void updateRotation (KeyCode oldKey, KeyCode newKey) {
		if (oldKey != newKey) {
			// Old Left
			if (oldKey == KeyCode.LeftArrow) {
				if (newKey == KeyCode.RightArrow) {
					Debug.Log("Rotation: Left -> Right");
					gameModel.playerRotation = GameModel.ROTATION_RIGHT;
				}
				else if (newKey == KeyCode.UpArrow) {
					Debug.Log("Rotation: Left -> Up");
					gameModel.playerRotation = GameModel.ROTATION_UP;
				}
				else if (newKey == KeyCode.DownArrow) {
					Debug.Log("Rotation: Left -> Down");
					gameModel.playerRotation = GameModel.ROTATION_DOWN;
				}
			}

			// Old Right
			else if (oldKey == KeyCode.RightArrow) {
				if (newKey == KeyCode.LeftArrow) {
					Debug.Log("Rotation: Right -> Left");
					gameModel.playerRotation = GameModel.ROTATION_LEFT;
				}
				else if (newKey == KeyCode.UpArrow) {
					Debug.Log("Rotation: Right -> Up");
					gameModel.playerRotation = GameModel.ROTATION_UP;
				}
				else if (newKey == KeyCode.DownArrow) {
					Debug.Log("Rotation: Right -> Down");
					gameModel.playerRotation = GameModel.ROTATION_DOWN;
				}
			}

			// Old Up
			else if (oldKey == KeyCode.UpArrow) {
				if (newKey == KeyCode.LeftArrow) {
					Debug.Log("Rotation: Up -> Left");
					gameModel.playerRotation = GameModel.ROTATION_LEFT;
				}
				else if (newKey == KeyCode.RightArrow) {
					Debug.Log("Rotation: Up -> Right");
					gameModel.playerRotation = GameModel.ROTATION_RIGHT;
				}
				else if (newKey == KeyCode.DownArrow) {
					Debug.Log("Rotation: Up -> Down");
					gameModel.playerRotation = GameModel.ROTATION_DOWN;
				}
			}

			// Old Down
			else if (oldKey == KeyCode.DownArrow) {
				if (newKey == KeyCode.LeftArrow) {
					Debug.Log("Rotation: Down -> Left");
					gameModel.playerRotation = GameModel.ROTATION_LEFT;
				}
				else if (newKey == KeyCode.RightArrow) {
					Debug.Log("Rotation: Down -> Right");
					gameModel.playerRotation = GameModel.ROTATION_RIGHT;
				}
				else if (newKey == KeyCode.UpArrow) {
					Debug.Log("Rotation: Down -> Up");
					gameModel.playerRotation = GameModel.ROTATION_UP;
				}
			}
		}
	}
}
