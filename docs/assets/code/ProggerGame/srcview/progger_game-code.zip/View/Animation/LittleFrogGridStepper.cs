﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LittleFrogGridStepper : MonoBehaviour {

	private GameModel gameModel = GameModel.GetInstance;
	private KeyCode lastKey = KeyCode.UpArrow;
	private float maxDistanceFromCenter = ((GameModel.NUM_OF_TILES * GameModel.TILE_SIZE) / 2) + GameModel.TILE_SIZE; 

	void Start() {
	}

	void Update() {

		if (gameModel.isMenuPanelVisible) {
			return;
		}

		Vector3 playerPosition = Vector3.zero;

		if (Input.GetKey(KeyCode.RightArrow) && haveSamePosition(transform.position, gameModel.playerPosition))
		{
			Debug.Log("Frog: Move Right");
			// New Move Position
			playerPosition = gameModel.playerPosition + (Vector3.right * GameModel.TILE_SIZE);
			if (Mathf.Abs(playerPosition.x) <= maxDistanceFromCenter) {
				gameModel.playerPosition = playerPosition;
				gameModel.madeNewGridStep = true;
			}

			// New Rotate Position
			updateRotation (lastKey, KeyCode.RightArrow);
			lastKey = KeyCode.RightArrow;
		}
		else if (Input.GetKey(KeyCode.LeftArrow) && haveSamePosition(transform.position, gameModel.playerPosition))
		{
			Debug.Log("Frog: Move Left");
			// New Move Position
			playerPosition = gameModel.playerPosition + (Vector3.left * GameModel.TILE_SIZE);
			if (Mathf.Abs(playerPosition.x) <= maxDistanceFromCenter) {
				gameModel.playerPosition = playerPosition;
				gameModel.madeNewGridStep = true;
			}

			// New Rotate Position
			updateRotation (lastKey, KeyCode.LeftArrow);
			lastKey = KeyCode.LeftArrow;
		}
		else if (Input.GetKey(KeyCode.UpArrow) && haveSamePosition(transform.position, gameModel.playerPosition))
		{
			Debug.Log("Frog: Move Up");
			// New Move Position
			playerPosition = gameModel.playerPosition + (Vector3.forward * GameModel.TILE_SIZE);
			if (Mathf.Abs(playerPosition.z) <= maxDistanceFromCenter) {
				gameModel.playerPosition = playerPosition;
				gameModel.madeNewGridStep = true;
			}

			// New Rotate Position
			updateRotation (lastKey, KeyCode.UpArrow);
			lastKey = KeyCode.UpArrow;
		}
		else if (Input.GetKey(KeyCode.DownArrow) && haveSamePosition(transform.position, gameModel.playerPosition))
		{
			Debug.Log("Frog: Move Down");
			// New Move Position
			playerPosition = gameModel.playerPosition + (Vector3.back * GameModel.TILE_SIZE);
			if (Mathf.Abs(playerPosition.z) <= maxDistanceFromCenter) {
				gameModel.playerPosition = playerPosition;
				gameModel.madeNewGridStep = true;
			}

			// New Rotate Position
			updateRotation (lastKey, KeyCode.DownArrow);
			lastKey = KeyCode.DownArrow;
		}

//		Vector3 dir = gameModel.playerPosition - transform.position;
//		Debug.DrawRay (transform.position, dir, Color.cyan, 5, true);
	}

	private void updateRotation (KeyCode oldKey, KeyCode newKey) {
		if (oldKey != newKey) {
			// Old Left
			if (oldKey == KeyCode.LeftArrow) {
				if (newKey == KeyCode.RightArrow) {
					Debug.Log("Rotation: Left -> Right");
					gameModel.playerRotation = GameModel.ROTATION_RIGHT;
				}
				else if (newKey == KeyCode.UpArrow) {
					Debug.Log("Rotation: Left -> Up");
					gameModel.playerRotation = GameModel.ROTATION_UP;
				}
				else if (newKey == KeyCode.DownArrow) {
					Debug.Log("Rotation: Left -> Down");
					gameModel.playerRotation = GameModel.ROTATION_DOWN;
				}
			}

			// Old Right
			else if (oldKey == KeyCode.RightArrow) {
				if (newKey == KeyCode.LeftArrow) {
					Debug.Log("Rotation: Right -> Left");
					gameModel.playerRotation = GameModel.ROTATION_LEFT;
				}
				else if (newKey == KeyCode.UpArrow) {
					Debug.Log("Rotation: Right -> Up");
					gameModel.playerRotation = GameModel.ROTATION_UP;
				}
				else if (newKey == KeyCode.DownArrow) {
					Debug.Log("Rotation: Right -> Down");
					gameModel.playerRotation = GameModel.ROTATION_DOWN;
				}
			}

			// Old Up
			else if (oldKey == KeyCode.UpArrow) {
				if (newKey == KeyCode.LeftArrow) {
					Debug.Log("Rotation: Up -> Left");
					gameModel.playerRotation = GameModel.ROTATION_LEFT;
				}
				else if (newKey == KeyCode.RightArrow) {
					Debug.Log("Rotation: Up -> Right");
					gameModel.playerRotation = GameModel.ROTATION_RIGHT;
				}
				else if (newKey == KeyCode.DownArrow) {
					Debug.Log("Rotation: Up -> Down");
					gameModel.playerRotation = GameModel.ROTATION_DOWN;
				}
			}

			// Old Down
			else if (oldKey == KeyCode.DownArrow) {
				if (newKey == KeyCode.LeftArrow) {
					Debug.Log("Rotation: Down -> Left");
					gameModel.playerRotation = GameModel.ROTATION_LEFT;
				}
				else if (newKey == KeyCode.RightArrow) {
					Debug.Log("Rotation: Down -> Right");
					gameModel.playerRotation = GameModel.ROTATION_RIGHT;
				}
				else if (newKey == KeyCode.UpArrow) {
					Debug.Log("Rotation: Down -> Up");
					gameModel.playerRotation = GameModel.ROTATION_UP;
				}
			}
		}
	}

	private bool haveSamePosition(Vector3 vec1, Vector3 vec2) {
		return Mathf.Round(vec1.x) == Mathf.Round(vec2.x) &&
			Mathf.Round(vec1.z) == Mathf.Round(vec2.z);
	}
}   
