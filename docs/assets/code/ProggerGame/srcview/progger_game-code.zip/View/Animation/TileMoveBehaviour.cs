﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileMoveBehaviour : MonoBehaviour {

	public float speed = 20.0F;

	private CharacterController controller;
	private Vector3 dir = Vector3.zero;

	// Use this for initialization
	void Start () {
		Debug.Log("Start TileMove");

		controller = GetComponent<CharacterController>();
	}
	
	// Update is called once per frame
	void Update () {

		Vector3 right = transform.TransformDirection(Vector3.right);
		float horizontalSpeed = speed * Input.GetAxis("Horizontal");
		controller.SimpleMove(right * horizontalSpeed);

		Vector3 forward = transform.TransformDirection(Vector3.forward);
		float verticalSpeed = speed * Input.GetAxis("Vertical");
		controller.SimpleMove(forward * verticalSpeed);
	}
}
