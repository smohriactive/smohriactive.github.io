﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileStepBehaviour : MonoBehaviour {

	private float speed = 0.2F;
	private float gravity = 0.7F;

	private GameModel gameModel = GameModel.GetInstance;
	private CharacterController controller;

	private Vector3 lastPosition = Vector3.zero;
	private Vector3 nextPosition = Vector3.zero;
	private Vector3 step = Vector3.zero;
	private Vector3 move = Vector3.zero;
	private bool isDirectionDirty = false;
	private bool isGravityDirty = false;

	// Use this for initialization
	void Start () {
		Debug.Log("Start TileMove");

		controller = GetComponent<CharacterController>();
	}

	// Update is called once per frame
	void Update () {

		if (gameModel.resetPosition) {
			gameModel.resetPosition = false;
			transform.position = gameModel.playerPosition;
		}

		bool upArrowDown = Input.GetKeyDown(KeyCode.UpArrow);
		bool downArrowDown = Input.GetKeyDown(KeyCode.DownArrow);
		bool leftArrowDown = Input.GetKeyDown(KeyCode.LeftArrow);
		bool rightArrowDown = Input.GetKeyDown(KeyCode.RightArrow);

		if (!isDirectionDirty & !isGravityDirty) {
			if (upArrowDown) {
				move = step = transform.TransformDirection(Vector3.forward * GameModel.TILE_SIZE);
				lastPosition = transform.position;
				nextPosition = transform.position + step;
				isDirectionDirty = true;
			} else if (downArrowDown) {
				move = step = transform.TransformDirection(Vector3.back * GameModel.TILE_SIZE);
				lastPosition = transform.position;
				nextPosition = transform.position + step;
				isDirectionDirty = true;
			} else if (leftArrowDown) {
				move = step = transform.TransformDirection(Vector3.left * GameModel.TILE_SIZE);
				lastPosition = transform.position;
				nextPosition = transform.position + step;
				isDirectionDirty = true;
			} else if (rightArrowDown) {
				move = step = transform.TransformDirection(Vector3.right * GameModel.TILE_SIZE);
				lastPosition = transform.position;
				nextPosition = transform.position + step;
				isDirectionDirty = true;
			}
		}

		if (isDirectionDirty) {
			float delta = Time.deltaTime;

			Debug.Log("Schritt: " + step + ", Pos-Ist: " + transform.position + ", Pos-Soll:" + nextPosition);

			CollisionFlags flags = controller.Move (move);

			// Check Step Complete
			move = nextPosition - transform.position;

			if (haveSamePosition (transform.position, nextPosition)) {
				Debug.Log("Pos gefunden !!!");

				gameModel.playerPosition = transform.position;

				isDirectionDirty = false;
				lastPosition = nextPosition;
				nextPosition = Vector3.zero;
				step = Vector3.zero;
				move = Vector3.zero;
				isGravityDirty = true;
			}
		}

		if (isGravityDirty) {
//			isGravityDirty = false;
			if (controller.isGrounded) {
				step = Vector3.zero;
				isGravityDirty = false;
			} else {
				step.y -= gravity * Time.deltaTime;
				controller.Move (step);
			}
		}
	}

	private bool haveSamePosition(Vector3 vec1, Vector3 vec2) {
		return Mathf.Round(vec1.x) == Mathf.Round(vec2.x) &&
			Mathf.Round(vec1.z) == Mathf.Round(vec2.z);
	}
}
