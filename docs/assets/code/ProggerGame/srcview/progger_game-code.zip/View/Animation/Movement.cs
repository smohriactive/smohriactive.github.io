﻿using UnityEngine;
using System.Collections;

public class Movement : MonoBehaviour {

	public float speed;
	public float jumpForce;
	public float smoothing;

	bool jump;

	Vector3 move;
	Vector3 lastMove;
	Vector3 gravity;

	float velX;
	float velY;
	float currentInpX;
	float currentInpY;

	CharacterController controller;
	public Transform cam;

	void Start () {
		controller = GetComponent<CharacterController>();
		jump = false;
	}

	void Update () {
		transform.rotation = Quaternion.Euler(0, cam.transform.eulerAngles.y, 0);

		if (Input.GetKey(KeyCode.Space) && controller.isGrounded) {
			jump = true;
		}

		float inpX = Input.GetAxisRaw("Horizontal");
		float inpY = Input.GetAxisRaw("Vertical");
		currentInpX = Mathf.SmoothDamp(currentInpX, inpX, ref velX, smoothing);
		currentInpY = Mathf.SmoothDamp(currentInpY, inpY, ref velY, smoothing);

		move = new Vector3(currentInpX, 0, currentInpY);
		move = Vector3.ClampMagnitude(move, 1);
		move = transform.TransformDirection(move);
		move *= speed;

		if (!controller.isGrounded) {
			move = Vector3.Lerp(lastMove, move, 0.05f);
		}
		lastMove = move;

		if (!controller.isGrounded) {
			gravity += Physics.gravity * Time.deltaTime;
		} else {
			gravity = Vector3.zero;
			if (jump) {
				jump = false;
				gravity.y = jumpForce;
			}
		}
		move += gravity;

		controller.Move(move * Time.deltaTime);
	}
}
