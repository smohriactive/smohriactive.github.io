﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerRotation : MonoBehaviour {

	private GameModel gameModel = GameModel.GetInstance;
	private KeyCode lastKey = KeyCode.UpArrow;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (gameModel.isMenuPanelVisible) {
			return;
		}

		if (Input.GetKey(KeyCode.RightArrow))
		{
			Debug.Log("Player: Rotate Right");

			// New Rotate Position
			updateRotation (lastKey, KeyCode.RightArrow);
			lastKey = KeyCode.RightArrow;
		}
		else if (Input.GetKey(KeyCode.LeftArrow))
		{
			Debug.Log("Player: Rotate Left");

			// New Rotate Position
			updateRotation (lastKey, KeyCode.LeftArrow);
			lastKey = KeyCode.LeftArrow;
		}
		else if (Input.GetKey(KeyCode.UpArrow))
		{
			Debug.Log("Player: Rotate forward");

			// New Rotate Position
			updateRotation (lastKey, KeyCode.UpArrow);
			lastKey = KeyCode.UpArrow;
		}
		else if (Input.GetKey(KeyCode.DownArrow))
		{
			Debug.Log("Player: Rotate back");

			// New Rotate Position
			updateRotation (lastKey, KeyCode.DownArrow);
			lastKey = KeyCode.DownArrow;
		}

		if (transform.rotation != gameModel.playerRotation) {
			transform.rotation = gameModel.playerRotation;
		}
	}

	private void updateRotation (KeyCode oldKey, KeyCode newKey) {
		if (oldKey != newKey) {
			// Old Left
			if (oldKey == KeyCode.LeftArrow) {
				if (newKey == KeyCode.RightArrow) {
					Debug.Log("Rotation: Left -> Right");
					gameModel.playerRotation = GameModel.ROTATION_RIGHT;
				}
				else if (newKey == KeyCode.UpArrow) {
					Debug.Log("Rotation: Left -> Up");
					gameModel.playerRotation = GameModel.ROTATION_UP;
				}
				else if (newKey == KeyCode.DownArrow) {
					Debug.Log("Rotation: Left -> Down");
					gameModel.playerRotation = GameModel.ROTATION_DOWN;
				}
			}

			// Old Right
			else if (oldKey == KeyCode.RightArrow) {
				if (newKey == KeyCode.LeftArrow) {
					Debug.Log("Rotation: Right -> Left");
					gameModel.playerRotation = GameModel.ROTATION_LEFT;
				}
				else if (newKey == KeyCode.UpArrow) {
					Debug.Log("Rotation: Right -> Up");
					gameModel.playerRotation = GameModel.ROTATION_UP;
				}
				else if (newKey == KeyCode.DownArrow) {
					Debug.Log("Rotation: Right -> Down");
					gameModel.playerRotation = GameModel.ROTATION_DOWN;
				}
			}

			// Old Up
			else if (oldKey == KeyCode.UpArrow) {
				if (newKey == KeyCode.LeftArrow) {
					Debug.Log("Rotation: Up -> Left");
					gameModel.playerRotation = GameModel.ROTATION_LEFT;
				}
				else if (newKey == KeyCode.RightArrow) {
					Debug.Log("Rotation: Up -> Right");
					gameModel.playerRotation = GameModel.ROTATION_RIGHT;
				}
				else if (newKey == KeyCode.DownArrow) {
					Debug.Log("Rotation: Up -> Down");
					gameModel.playerRotation = GameModel.ROTATION_DOWN;
				}
			}

			// Old Down
			else if (oldKey == KeyCode.DownArrow) {
				if (newKey == KeyCode.LeftArrow) {
					Debug.Log("Rotation: Down -> Left");
					gameModel.playerRotation = GameModel.ROTATION_LEFT;
				}
				else if (newKey == KeyCode.RightArrow) {
					Debug.Log("Rotation: Down -> Right");
					gameModel.playerRotation = GameModel.ROTATION_RIGHT;
				}
				else if (newKey == KeyCode.UpArrow) {
					Debug.Log("Rotation: Down -> Up");
					gameModel.playerRotation = GameModel.ROTATION_UP;
				}
			}
		}
	}
}
