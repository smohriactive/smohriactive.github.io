﻿using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class SimpleMoveBehaviour : MonoBehaviour {
	
	public float speed = 20.0F;
	public float rotateSpeed = 20.0F;

	private CharacterController controller;

	// Use this for initialization
	void Start () {
		Debug.Log("Start SimpleMove");

		controller = GetComponent<CharacterController>();
	}

	// Update is called once per frame
	void Update() {
		transform.Rotate(0, Input.GetAxis("Horizontal") * rotateSpeed, 0);
		Vector3 forward = transform.TransformDirection(Vector3.forward);
		float curSpeed = speed * Input.GetAxis("Vertical");
		controller.SimpleMove(forward * curSpeed);
	}
}
