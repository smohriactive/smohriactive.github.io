﻿using UnityEngine;
using System.Collections;

public class CircleMotion : MonoBehaviour
{
	public Transform target;
	public float radius = 2f;     
	public float currentAngle = 0f;
	public float timeToCompleteCircle = 1.5f; 

	private float speed = 0f;     

	void Awake()
	{
		speed = (Mathf.PI * 2) / timeToCompleteCircle;
	}

	// Use this for initialization
	void Start ()
	{

	}

	// Update is called once per frame
	void Update ()
	{
		speed = (Mathf.PI * 2) / timeToCompleteCircle;
		currentAngle += Time.deltaTime * speed;
		float newX = target.position.x + (radius * Mathf.Cos (currentAngle));
		float newZ = target.position.z + (radius * Mathf.Sin (currentAngle));
		transform.position = new Vector3 (newX, transform.position.y, newZ);
	}
}
