﻿using UnityEngine;
using System.Collections;

public class SwitchCamera : MonoBehaviour {

	public Camera followCamera;
	public Camera upCamera;

	void Start () {
		followCamera.enabled = true; 
		upCamera.enabled = false; 
	}

	void Update () {
		if (Input.GetKeyDown("1"))
		{
			followCamera.enabled = true;
			upCamera.enabled = false;
		}
		if (Input.GetKeyDown("2"))
		{
			followCamera.enabled = false;
			upCamera.enabled = true;
		}
	}
}
