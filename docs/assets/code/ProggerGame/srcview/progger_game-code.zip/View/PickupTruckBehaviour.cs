﻿using UnityEngine;

public class PickupTruckBehaviour : MonoBehaviour {

	private const string EMPTY = "Empty";
	private const string LADEFLAECHE = "Ladeflaeche";
	private const string WOHNRAUM = "Wohnraum";

	// Use this for initialization
	void Start () {
		Debug.Log("Start PickupTruck");

		Renderer[] components = GetComponentsInChildren<Renderer>();
		string[] choiceNames = new string[]{EMPTY, LADEFLAECHE, WOHNRAUM};
		int choice = Random.Range (0, 3);

		foreach (Renderer childRenderer in components) {

			switch (choiceNames[choice]) {
				case LADEFLAECHE:
					if (childRenderer.name == WOHNRAUM) {
						childRenderer.enabled = false;
					}
					break;
				case WOHNRAUM:
					if (childRenderer.name == LADEFLAECHE) {
						childRenderer.enabled = false;
					}
					break;
				default:
					if (childRenderer.name == LADEFLAECHE) {
						childRenderer.enabled = false;
					}
					if (childRenderer.name == WOHNRAUM) {
						childRenderer.enabled = false;
					}
					break;
			}
		}

		transform.rotation = Quaternion.Euler(0, -90, 0);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
