﻿using UnityEngine;
using UnityEngine.UI;

public class NavigationManager : MonoBehaviour {
	
	private GameModel gameModel = GameModel.GetInstance;
	private Button[] buttons;

	// Use this for initialization
	void Start () {
		buttons = FindObjectsOfType<Button>();
        foreach (Button btn in buttons) {
			btn.gameObject.SetActive(false);
        }
	}
	
	// Update is called once per frame
	void Update () {
		if (gameModel.isGameOver) {
			foreach (Button btn in buttons) {
				btn.gameObject.SetActive(true);
			}
		} else {
			foreach (Button btn in buttons) {
				btn.gameObject.SetActive(false);
			}
		}
	}
}
