﻿using System;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LevelVO
{
	public int LevelNumber;
	public string LevelName;

	public List<RoundVO> rounds;
	public int currentRoundIndex;
	public RoundVO currentRound;

	public LevelVO () {
		rounds = new List<RoundVO> ();

		for (int i = 0; i < 5; i++) {
			RoundVO round = new RoundVO ();
			rounds.Add (round);

			if (i == 0) {
				currentRound = round;
				currentRoundIndex = 0;
			}
		}
	}
}
