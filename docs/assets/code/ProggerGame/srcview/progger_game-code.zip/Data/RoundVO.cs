﻿using System;
using UnityEngine;

public class RoundVO
{
	public bool isRoundFinished = false;
	public float highestForwardPosition = GameModel.PLAYER_START_POS_Z;
	public Vector3 playerPosition = GameModel.PLAYER_START_POS;
	public Quaternion playerRotation;
}
