﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class GameModel {
	public const int SPAWN_SIZE = 100;
	public const int GAME_SIZE = 40;
	public const float SPEED_NPC = 20f;
	public const float SPEED_PLAYER = 5000f;

	public const int NUM_OF_TILES = 13;
	public const float TILE_SIZE = 7f;

	public const float GAME_HEALTH = 1f;
	public const float GAME_DAMAGE = 1f; // 0.3f;

	public const int POINTS_STEP = 10;
	public const int POINTS_HOME = 200;

	public static Quaternion ROTATION_LEFT = Quaternion.Euler(0, -90, 0);
	public static Quaternion ROTATION_RIGHT = Quaternion.Euler(0, 90, 0);
	public static Quaternion ROTATION_UP = Quaternion.Euler(0, 0, 0);
	public static Quaternion ROTATION_DOWN = Quaternion.Euler(0, 180, 0);

	public static float PLAYER_START_POS_Z = -(GameModel.TILE_SIZE * 6);
	public static Vector3 PLAYER_START_POS = new Vector3 (0f, 1f, PLAYER_START_POS_Z);

	private static GameModel instance;

	private GameModel() {}

	public static GameModel GetInstance {
		get {
			if (instance == null) {
				instance = new GameModel();
			}
			return instance;
		}
	}

	public List<GameObject> npcList = new List<GameObject>();
	public bool isOptionsPanelVisible = false;
	public bool isMenuPanelVisible = true;
	public bool isGamePaused = false;
	public bool isGameOver = false;
	public float health = 1f;
	public float pointsValue = 0f;
	public float hiScoreValue = 0f;
	public float highestForwardPosition = PLAYER_START_POS_Z;
	public bool resetPosition = false;
	public Vector3 playerPosition = PLAYER_START_POS;
	public Quaternion playerRotation;
	public bool isTransporting = false;
	public bool madeNewGridStep = false;

//	public GameVO currentGame;
//	public LevelVO currentLevel;
//	public RoundVO currentRound;
}
